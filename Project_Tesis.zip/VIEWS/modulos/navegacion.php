<nav>
		<ul>
			<li><a href="index.php">Inicio</a></li>
			<li><a href="index.php?action=Nosotros">Nosotros</a></li>
			<li><a href="index.php?action=Servicios">Servicios</a></li>
			<li><a href="index.php?action=Contactenos">Contáctenos</a></li>
		</ul>
</nav>