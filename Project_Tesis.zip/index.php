<?php

require_once "CONTROLLERS/Controller.php";
require_once "MODELS/model.php";
$mvc = new MvcController();
$mvc -> plantilla();

?>